# V0.3 ir V0.4 Versijos

# V0.3
## Kas padaryta?
1. Funkcijos ir strŪktūros pridėtos į headerius (struktura.h, funkcijos.h)
2. Daugelis funkcijų pridėtos į funkcijos.cpp failą
3. Panaudotas išimčių valdymas
# V0.4
## Kas padaryta?
1. Vartotojui siūloma pasirinkti: '1' - kad duomenys būtų sugeneruoti automatiškai, '0' - negeneruoti automatiškai.
2. Pasirinkus generuoti failus automatiškai, bus sukuriami studentų sąrašų failai, sudaryt iš: 1000, 10000, 100000, 1000000, 10000000 įrašų.
3. Sugeneruoti įrašai bus nuskaitomi iš duomenų į strūktūras.
4. Studentai bus surūšiuoti pagal pažymius ir išskirstomi: "vargšiukai",  jei (galutinis balas < 5), "galvočiai", (jei galutinis balas >= 5).
5. Programa išves du surūšiuotų studentų tekstinius failus: "vargsiukai.txt" ir "galvociai.txt".
6. Atlikta programos veikimo greičio analizė: išmatuota kiekviena programos sparta
7. Programos veikimo laikas yra įrašytas į V0.3 šaką, pavadinimu "laikas.png"
